

public abstract class Usuario
  {
    
  }