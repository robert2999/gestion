public class administracion
{
    private String nomUsu;
    private colas<String>tramitesPendientes;
    public administracion(String nomUsu
    {
        this.nombre = nombre;
        this.tramitesPendientes = new colas<>();
    }
    public void agregarTramite(String descripcion)
    {
        tramitesPendientes.encolar(descripcion);
        System.out.println("Trámite pendiente creado: " + descripcion);
    }
    
}

